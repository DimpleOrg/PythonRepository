# -*- coding: utf-8 -*-
"""
Created on Fri Feb 12 21:49:24 2021

@author: dimpl
"""
import pygame
# from pygame.sprite import Sprite


class Alien():
    """A class to represent a single alien in the fleet."""

    def __init__(self, ai_game):
        """Initialize the alien and set its starting position."""
        # super().__init__()
        self.screen = ai_game.screen

        # # Load the alien image and set its rect attribute.
        # self.image = pygame.image.load("alien.bmp")
        # self.rect = self.image.get_rect()

        # # Start each new alien near the top left of the screen.
        # self.rect.x = self.rect.width
        # self.rect.y = self.rect.height

        self.settings = ai_game.settings
        self.color = self.settings.alien_color

        # Create a bullet rect at (0, 0) and then set correct position.
        screen_rect = self.screen.get_rect()
        self.rect = pygame.Rect(
            0, 0, self.settings.alien_width, self.settings.alien_height)
        self.rect.bottomright = screen_rect.bottomright

        # Store the alien's exact horizontal position.
        self.y = float(self.rect.y)

    def check_edges(self):
        """Return True if alien is at edge of screen."""
        screen_rect = self.screen.get_rect()
        if self.rect.top <= 0 or self.rect.bottom >= screen_rect.bottom:
            return True

    def update(self):
        # """Move the alien right or left."""
        # self.x += (self.settings.alien_speed *
        #            self.settings.fleet_direction)
        # # print(self.settings.fleet_direction)
        # self.rect.x = self.x
        """Move the alien up or down."""
        self.y -= (self.settings.alien_speed *
                   self.settings.fleet_direction)
        self.rect.y = self.y

    def draw_alien(self):
        """Draw the alien to the screen."""
        pygame.draw.rect(self.screen, self.color, self.rect)
